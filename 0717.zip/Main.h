#pragma once

#include "resource.h"

#include "stdafx.h"
#include "Scene.h"
#include "TitleScene.h"
#include "GameScene.h"
#include "GameOverScene.h"

#include "SceneManager.h"