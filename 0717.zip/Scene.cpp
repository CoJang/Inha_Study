#include "stdafx.h"
#include "Scene.h"


Scene::Scene()
{
	type = TITLE;
}

Scene::~Scene()
{
}
