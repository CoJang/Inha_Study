#pragma once

class keyAniManager
{
};

