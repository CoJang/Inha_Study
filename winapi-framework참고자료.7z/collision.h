#pragma once
class collision
{
};

